function out = imDecimation( image, D);



[m n] = size(image);

out = uint8( zeros( fix( m / D ), fix( n / D ) ) );

k=1;

for i=1:D:m

	l=1;

	for j=1:D:n

		out(k,l)=image(i,j);	

		l=l+1;

	end

	k=k+1;

end







endfunction