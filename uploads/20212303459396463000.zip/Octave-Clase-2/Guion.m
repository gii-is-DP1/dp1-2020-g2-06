close all
clear all
clc

%%%%%%%%%%%%%
%%Ejemplo 1%%
%%%%%%%%%%%%%
IN = imread('helicoptero.bmp'); %%mostrar imagen
[filas, clos, canales] = size(IN);
imshow(IN);
pixel = IN(1,12) %%Intensidad en el pixel  1,12
pixel = IN(10,15)

%%%%%%%%%%%%%%
%%Ejercicio1%%
%%%%%%%%%%%%%%
in_invert = 255-IN;
imshow(in_invert);

%%%%%%%%%%%%%
%%Ejemplo 2%%
%%%%%%%%%%%%%
h = histogram(IN, 1);
figure(2);
showHisto(h);

%%%%%%%%%%%%%
%%Ejemplo 3%%
%%%%%%%%%%%%%


%%%%%%%%%%%%%
%%Ejemplo 4%%
%%%%%%%%%%%%%
IN = imread('mezcla.jpg');
IN = imread('cuadro.bmp');

[filas,cols,canal] = size(IN)
  
  R = IN; G = IN; B = IN;

[R,G,B] = Canales(IN);

figure();
imshow(R);

figure();
imshow(G);

figure();
imshow(B);

%%%%%%%%%%%%%
%%Ejemplo 5%%
%%%%%%%%%%%%%

IN = imread('Cuadro.bmp');
[filas,cols,canales] = size(IN);
imshow(IN);

OUT = rgb2gray(IN);

figure();
imshow(OUT);

%%%%%%%%%%%%%
%%Ejemplo 7%%
%%%%%%%%%%%%%

IN = imread('pijama.bmp'); 

%IN = imread('Cuadro.bmp'); 

[filas, cols, canales] = size(IN);

imshow(IN);


R = IN(:,:,1); 

G = IN(:,:,2);

B = IN(:,:,3);




Rnorm = normaliza(R); %Completar la funcion normaliza

Gnorm = normaliza(G);

Bnorm = normaliza(B);


for ind=1:filas

  for jnd=1:cols

   [h, l, s] = rgb2hls(Rnorm(ind, jnd), Gnorm(ind, jnd), Bnorm(ind, jnd)); %Completar la funcion rgb2hls

   H(ind, jnd) = h;

   L(ind, jnd) = l;

   S(ind, jnd) = s;

  endfor

endfor


H = round( H ); H( H == 360 ) = 0; H = H(:);

hh = zeros( 360, 1 );

for i = 0 : 359

 hh( i + 1 ) = sum( H == i );

end


figure();

showHisto(hh,360)