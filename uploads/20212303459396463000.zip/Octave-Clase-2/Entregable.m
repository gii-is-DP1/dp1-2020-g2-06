close all
clear all
clc



R=IN(:,:,1); 
G=IN(:,:,2);
B=IN(:,:,3);

gris=rgb2gray(IN);
[umbral, mu1, mu2] = MVThreshold(histogram(gris,1));
gris = Binarizacion(gris,umbral);

IN=imread('fotos/prueba216.jpg');
[filas,cols,canales]=size(IN);
imshow(IN);

Area = 0.0;
Perimetro = 0.0;
for ind=1:filas-1
  for jnd=1:cols-1
    if(IN(ind,jnd) == 0)
      Area +=1;
    endif
    endfor
endfor


figure();
imshow(IN);
title(strcat("El area de la fruta es de: ", strcat(num2str(Area)," pixeles")));

X = imBorder(gris);
figure();
imshow(X);

[f,co,ca]=size(gris);

for ind=1:f

  for jnd=1:co
  
    if(X(ind,jnd) < 80)
      X(ind,jnd) = 0; 
    else
      X(ind,jnd) = 255;
    endif
  endfor

endfor

figure();
imshow(X);

Rnorm = normaliza(R); %Completar la funcion normaliza
Gnorm = normaliza(G);
Bnorm = normaliza(B);



for ind=1:filas

  for jnd=1:cols

   [h, l, s] = rgb2hls(Rnorm(ind, jnd), Gnorm(ind, jnd), Bnorm(ind, jnd)); %Completar la funcion rgb2hls

   H(ind, jnd) = h;

   L(ind, jnd) = l;

   S(ind, jnd) = s;

  endfor

endfor

H = round( H ); H( H == 360 ) = 0; H = H(:);

hh = zeros( 360, 1 );

for i = 0 : 359

 hh( i + 1 ) = sum( H == i );

end

figure();

showHisto(hh,360);

