function M = ACProm(histo) 

% 

M = zeros(1,256);



% Suma acumulativa de M: posicion anterior por valor de histo mas valor anterior de M (pista i=2:256)



for i=2:256

 M(i) = (i-1)*histo(i) + M(i-1);

end

end