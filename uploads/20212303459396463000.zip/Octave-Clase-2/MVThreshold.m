function [umbral, mu1, mu2] = MVThreshold(histo) 

% El algoritmo presupone que el histograma es Binodal

% Devuelve el umbral y la posici�n de los m�ximos de 

% los dos nodos principales.

SA = ACS(histo);

M = ACProm(histo);



umbral = fix(M(256)/SA(256));

last = 1;



 while (last != umbral)

  last = umbral;

  mu1 = M(umbral)/SA(umbral);

  mu2 = (M(256)-M(umbral))/(SA(256)-SA(umbral));

  umbral = fix((mu1 + mu2)/2);

 endwhile

  

endfunction