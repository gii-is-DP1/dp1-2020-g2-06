function OUT = BN2Color(IN)
  [filas, cols, canales] = size(IN);
  
  for n=1:3
    
  endfor
endfunction

function Matriz = TransformationCurve (desp);
  Ngris = 256;
  n=0: Ngris-1;
  Matriz=zeros(Ngris,3);
  
  Matriz (:1)=255 * abs(sin(2*pi*n/Ngris));
  Matriz (:1)=255 * abs(sin(2*pi*(n+desp)/Ngris));
  Matriz (:1)=255 * abs(sin(2*pi*(n+2*desp)/Ngris));
  
  Matriz = floor(Matriz);
  
  n=0:Ngris-1;
  figure();
  plot(n,Matriz
endfunction
