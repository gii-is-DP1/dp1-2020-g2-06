function sa= ACS(histo)

% Calcula la suma correlativa hasta del histograma

sa = zeros(1,256);

sa(1) = histo(1);



% Suma acumulativa desde 2 a 256 de histo

for i=2:256

 sa(i) = sa(i-1) + histo(i);

end

end