close all
clear all
clc

IN=imread('helicoptero.bmp');
[filas,cols,canales]=size(IN);
pixel=IN(1,12)
pixel=IN(10,15)

in_invert = 255 - IN;
imshow(in_invert)

OUT=bitxor(IN,255);
figure();
imshow(OUT);


IN=imread('helicoptero.bmp');
[filas,cols,canales]=size(IN);
imshow(IN);

h=histogram(IN,1);

figure(2);
showHisto(h);

IN=imread('infrarojo.bmp');
[filas,cols,canales]=size(IN);
imshow(IN);


IN = imread('mezcla.jpg'); %modificar por el alumno
[filas, cols, canales] = size(IN);
imshow(IN);

[R, G, B] = Canales(IN); %Completar la funcion Canales

figure();
imshow(R);

figure();
imshow(G);

figure();
imshow(B);

IN = imread('cuadro.bmp'); %modificar por el alumno
[filas, cols, canales] = size(IN);
imshow(IN);

hr=histogram(IN,1);
hg=histogram(IN,2);
hb=histogram(IN,3);

figure();
showHisto(hr);

IN = imread('cuadro.bmp'); %modificar por el alumno
[filas, cols, canales] = size(IN);
imshow(IN);

OUT=rgb2gray(IN);

figure();
imshow(OUT);


IN = imread('pijama.bmp'); %modificar por el alumno
[filas, cols, canales] = size(IN);
imshow(IN);

R=IN(:,:,1);
G=IN(:,:,2);
H=IN(:,:,3);

Rnorm = normaliza(R); %Completar la funcion normaliza

Gnorm = normaliza(G);

Bnorm = normaliza(B);

for ind=1:filas

  for jnd=1:cols

   [h, l, s] = rgb2hls(Rnorm(ind, jnd), Gnorm(ind, jnd), Bnorm(ind, jnd)); %Completar la funcion rgb2hls

   H(ind, jnd) = h;

   L(ind, jnd) = l;

   S(ind, jnd) = s;

  endfor

endfor

H = round( H ); H( H == 360 ) = 0; H = H(:);

hh = zeros( 360, 1 );

for i = 0 : 359

 hh( i + 1 ) = sum( H == i );

end

figure();

showHisto(hh,360);

IN=imread('naranjas-verano.jpg');
[filas,cols,canales]=size(IN);
imshow(IN);

h=histogram(IN,1);

figure(2);
showHisto(h);


OUT=rgb2gray(IN);

figure();
imshow(OUT);

R=IN(:,:,1);
G=IN(:,:,2);
H=IN(:,:,3);

Rnorm = normaliza(R); %Completar la funcion normaliza

Gnorm = normaliza(G);

Bnorm = normaliza(B);

for ind=1:filas

  for jnd=1:cols

   [h, l, s] = rgb2hls(Rnorm(ind, jnd), Gnorm(ind, jnd), Bnorm(ind, jnd)); %Completar la funcion rgb2hls

   H(ind, jnd) = h;

   L(ind, jnd) = l;

   S(ind, jnd) = s;

  endfor

endfor

H = round( H ); H( H == 360 ) = 0; H = H(:);

hh = zeros( 360, 1 );

for i = 0 : 359

 hh( i + 1 ) = sum( H == i );

end

figure();

showHisto(hh,360);


IN=imread('naranjas-verano.jpg');
[filas,cols,canales]=size(IN);
out = hboost(IN, 5, 20);

