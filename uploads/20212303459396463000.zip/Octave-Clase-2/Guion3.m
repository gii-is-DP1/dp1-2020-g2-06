close all
clear all
clc

IN = imread('fotos/Objetos.jpg');
[filas,cols,canales] = size(IN);
imshow(IN);
threshold = 180;

bwimage = Binarizacion(IN, threshold);
figure(2);
imshow(bwimage);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

IN = imread('fotos/galletabordes.jpg');

Imgs = {'fotots/galletabordes.jpg'};



[filas, cols, canales] = size(IN);

figure()

subplot(2,1,1)

imshow(IN);



histo = histogram(IN, 1);

[umbral, mu1, mu2] = MVThreshold(histo); %Completar la funcion histogram

sprintf( 'Imgs= %s, u=%d, mu1=%d, mu2=%d\n', Imgs{1},umbral, mu1, mu2 )



subplot(2,1,2)

showHisto(histo);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%IN = imread('fotos/eye.jpg');

%IN = imread('fotos/Imag_ruido1.png');

IN = imread('fotos/Imag_ruido2.png');

[filas, cols, canales] = size(IN);

figure();

imshow(IN);



mask = [1 1 1; 1 8 1; 1 1 1];

%mask = [1 1 1; 1 1 1; 1 1 1]/9; % Filtro promedio

%mask = [1 1 1; 1 2 1; 1 1 1]/10; % Filtro triangular 1 

%mask = [1 2 1; 2 4 2; 1 2 1]/16; % Filtro triangular 2 

%mask = [0.0113 0.0838 0.0113; 0.0838 0.6193 0.0838; 0.0113 0.0838 0.0113]; % Filtro Gaussiano 



R = imConvolve(IN, mask); %Completar

%R;

%Reajuste de la imagen

maxval = max(max(R));

minval = min(min(R));

if (maxval > 255 | minval<0)

 RR = imRemap(R);

else

% RR = imRemap(R);

 RR = uint8(R);

end



figure();

imshow(RR);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

