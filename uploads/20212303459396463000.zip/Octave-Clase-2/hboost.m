function out = hboost(image, N, a)



if nargin < 3

	error('Faltan argumentos');

end

if rem(N,2)==0 || N==1

	error('N debe ser impar mayor que 1');

end



mask = -ones(N,N);

c=fix(N/2)+1;

A=N^2 -1 + a;

mask(c,c) = A ;



out1 = imConvolve(image, mask);

out = imRemap(out1);



figure()

imshow(image);

figure()

imshow(out);



endfunction