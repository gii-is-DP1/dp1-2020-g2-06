function normal = normaliza(IN)
  normal = single( IN ) / 255;
endfunction